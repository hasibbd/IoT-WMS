<?php
include("phpclass.php");
$obj = new AjaxCrud();
$table = "wms";
$id = 1;
if (isset($_POST['readrecords'])) {
    
    $number = $_POST['number'];
    $obj->UpdateDataDevice($id, $number, $table);
    $res = $obj->showData($table);
    $arr = array(
        'mtank' => $res[0]['mtank'],
        'rtank' => $res[0]['rtank'],
        'aswitch' => $res[0]['aswitch'],
        'pswitch' => $res[0]['pswitch'],
        'tapswitch' => $res[0]['tapswitch'],
        'aswitchstatus' => $res[0]['aswitchstatus'],
        'pswitchstatus' => $res[0]['pswitchstatus'],
        'tapswitchstatus' => $res[0]['tapswitchstatus'],
        'devicestatus' => $res[0]['devicestatus']
    );
    echo json_encode($arr);

    
}

if (isset($_POST['s1'])) {
    if ($_POST['s1'] == "off") {
        $autoswith = "on";
    } else {
        $autoswith = "off";
    }
    $obj->UpdateDataAuto($id, $autoswith, $table);
}
if (isset($_POST['s2'])) {
    if ($_POST['s2'] == "off") {
        $pumpswitch = "on";
    } else {
        $pumpswitch = "off";
    }
    $obj->UpdateDataPump($id, $pumpswitch, $table);
}
if (isset($_POST['s3'])) {
    if ($_POST['s3'] == "off") {
        $tapswitch = "on";
    } else {
        $tapswitch = "off";
    }
    $obj->UpdateDataTap($id, $tapswitch, $table);
}

?>