<?php

class AjaxCrud
{
    private $host = "localhost";
    private $user = "root";
    private $db = "wms";
    private $pass = "";
    private $conn;

    public function __construct()
    {
        $this->conn = new mysqli($this->host, $this->user, $this->pass, $this->db);
    }

    public function showData($table)
    {
        $sql = "SELECT * FROM $table";
        $q = $this->conn->query($sql) or die("failed!");
        while ($row = mysqli_fetch_assoc($q)) {
            $data[] = $row;
        }
        return $data;
    }

    public function getById($id, $table)
    {
        $sql = "SELECT * FROM $table WHERE id = $id";
        $q = $this->conn->query($sql);
        $row = mysqli_fetch_assoc($q);
        return $row;
    }

    public function UpdateData($id, $aswitch, $pswitch, $tapswitch, $table)
    {
        $sql = "UPDATE `$table` SET `aswitch`='$aswitch',`pswitch`= '$pswitch', `tapswitch` ='$tapswitch' WHERE `id`='$id '";
        $this->conn->query($sql);

    }
    public function UpdateDataAuto($id, $aswitch, $table)
    {
        $sql = "UPDATE `$table` SET `aswitch`='$aswitch' WHERE `id`='$id '";
        $this->conn->query($sql);

    }
    public function UpdateDataPump($id, $pswitch, $table)
    {
        $sql = "UPDATE `$table` SET `pswitch`= '$pswitch' WHERE `id`='$id '";
        $this->conn->query($sql);

    }
    public function UpdateDataTap($id, $tapswitch, $table)
    {
        $sql = "UPDATE `$table` SET `tapswitch` ='$tapswitch' WHERE `id`='$id '";
        $this->conn->query($sql);

    }

    public function InsertData($mtank, $rtank, $aswitch, $pswitch, $aswitchstatus, $pswitchstatus, $table)
    {
        $sql = "INSERT INTO $table (`mtank`, `rtank`, `aswitch`, `pswitch`, `aswitchstatus`, `pswitchstatus`)";
        $sql .= "VALUES ('$mtank', '$rtank','$aswitch', '$pswitch','$aswitchstatus', '$pswitchstatus')";
        $this->conn->query($sql);
    }

    public function deleteData($id, $table)
    {
        $sql = "DELETE FROM $table WHERE `id` = '$id'";
        $this->conn->query($sql);
    }
}

?>

